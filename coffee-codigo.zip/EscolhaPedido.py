from ClassePedido import Pedido
from ClasseProduto import Produto
from ClasseCliente import Cliente
from textoColorido import textoColorido
def escolhaPedido():
    textoColorido('Criar ou listar?','azul')
    textoColorido('1-Criar | 2-Listar','azul')
    texto=input('')
    if(not texto.isdigit()):
        textoColorido('Número inválido','vermelho')
        return
    decisao=int(texto)
    if(decisao==1): # Criação de um pedido
        textoColorido('Digite o id do Cliente:','azul')
        texto=input('')
        if(not texto.isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        idCliente=int(texto)
        cliente=Cliente.encontrarClientePorId(idCliente) 
        if(not cliente): # Checa existência do Cliente
            textoColorido('Não existe Cliente com este id','vermelho')
            return
        novoPedido=Pedido(cliente)
        novoItem=None
        while(novoItem!=0): # Inicia um loop para adicionar itens ao pedido, até ser encerrado com o número 0
            textoColorido('Digite o id do Produto que quer adicionar, ou 0 para finalizar o Pedido','azul')
            texto=input('')
            if(not texto.isdigit()):
                textoColorido('Número inválido','vermelho')
                return
            novoItem=int(texto)
            if(novoItem!=0):
                produto=Produto.encontrarProdutoPorId(novoItem)
                if(not produto): # Checa existência do Produto
                    textoColorido('Não existe Produto com este id','vermelho')
                    return
                novoPedido.adicionarProduto(produto)
        novoPedido.finalizarPedido()
    elif(decisao==2): # Checagem de Pedidos
        Pedido.listar()
    else:
        textoColorido('Número inválido','vermelho')