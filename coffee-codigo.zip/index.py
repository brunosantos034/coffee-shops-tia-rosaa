from EscolhaCliente import escolhaCliente
from EscolhaPedido import escolhaPedido
from EscolhaProduto import escolhaProduto
from textoColorido import textoColorido
# O loop while continuará sendo repetido, mantendo o programa rodando
while(True): 
    textoColorido('Qual das opções você deseja criar ou listar?','azul')
    textoColorido('1-Cliente | 2-Pedido | 3-Produto','azul')
    texto=input('')
    if(not texto.isdigit()): # O texto digitado pelo usuário é verificado se é numerico, para não gerar erro na conversão para inteiro
        textoColorido('Número inválido','vermelho')
        continue
    decisao=int(texto) # A escolha do usuário é convertida para número e entra na condição correspondente
    if(decisao==1):
        escolhaCliente() # Instância Cliente foi escolhida, continua no arquivo EscolhaCliente.py
    elif(decisao==2):
        escolhaPedido() # Instância Pedido foi escolhida, continua no arquivo EscolhaPedido.py
    elif(decisao==3):
        escolhaProduto() # Instância Produto foi escolhida, continua no arquivo EscolhaProduto.py
    else:
        textoColorido('Número inválido','vermelho')
        # A resposta não é válida, o programa exibe a mensagem de erro e volta ao início