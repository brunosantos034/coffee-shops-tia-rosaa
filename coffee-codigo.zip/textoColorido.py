def textoColorido(texto,cor):
    if(cor=='vermelho'):
        codigo="\033[31m"
    elif(cor=='verde'):
        codigo="\033[32m"
    elif(cor=='azul'):
        codigo="\033[34m"
    elif(cor=='amarelo'):
        codigo="\033[33m"
    finalCodigo="\033[0m"
    # Essa fução recebe o texto e a cor escolhida
    # E Junta o código da cor com o texto
    print(codigo+texto+finalCodigo)