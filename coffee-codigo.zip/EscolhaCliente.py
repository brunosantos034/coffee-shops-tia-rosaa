from ClasseCliente import Cliente
from textoColorido import textoColorido
def escolhaCliente():
    textoColorido('Criar ou listar?','azul')
    textoColorido('1-Criar | 2-Listar | 3-Usar Pontos','azul')
    texto=input('')
    if(not texto.isdigit()):
        textoColorido('Número inválido','vermelho')
        return
    decisao=int(texto)
    if(decisao==1): # Criação de Cliente
        textoColorido('Digite o nome:','azul')
        nome=input('')
        Cliente(nome)
    elif(decisao==2): # Checagem dos Clientes
        Cliente.listar()
    elif(decisao==3): # Desconto de pontos do Cliente, caso tenha saldo suficiente
        textoColorido('Digite o id do Cliente:','azul')
        texto=input('')
        if(not texto.isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        idCliente=int(texto)
        cliente=Cliente.encontrarClientePorId(idCliente) # Procura a instância de Cliente com o id passado pelo usuário
        if(not cliente): # Checa se o valor retornado é nulo
            textoColorido('Não existe Cliente com este id','vermelho')
            return
        textoColorido('Digite a quantidade de pontos a serem usados:','azul')
        texto=input('')
        if(not texto.isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        pontos=int(texto)
        Cliente.usarPontos(cliente,pontos) # Chama o método usarPontos, com a quantidade passada pelo usuário
    else:
        textoColorido('Número inválido','vermelho')