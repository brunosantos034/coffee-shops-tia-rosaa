from textoColorido import textoColorido
id=1
RELACAO_PONTO_PRECO=10 # Define quantos pontos o Cliente ganha para cada real gasto
class Cliente:
    clientes=[]
    
    def __init__(self,nome): # Método de criação de um objeto da classe Cliente
        global id
        self.id=id
        id=id+1
        self.nome=nome
        self.pontos=0
        Cliente.clientes.append(self) # Adiciona o novo Cliente à lista
        textoColorido(f'Cliente criado com sucesso!','verde')
    def listar():
        textoColorido('Clientes:','azul')
        for c in Cliente.clientes:
            print(f'ID:{c.id} - {c.nome} - {c.pontos} pontos')
    def encontrarClientePorId(idCliente):
        for c in Cliente.clientes:
            if(c.id==idCliente):
                return c
    def aumentarPontos(self,valorGasto):
        # Método que adiciona pontos ao Cliente, baseado na relação definida no início deste arquivo
        pontosGanhos=valorGasto*RELACAO_PONTO_PRECO
        self.pontos=self.pontos+pontosGanhos
        textoColorido(f'{pontosGanhos:.0f} pontos ganhos','azul')
    def usarPontos(cliente,pontosUsados):
        # Checa se o Cliente tem pontos o suficiente para o pedido de uso
        if(cliente.pontos>=pontosUsados):
            cliente.pontos=cliente.pontos-pontosUsados # Desconta os pontos usados
            textoColorido(f'{pontosUsados} pontos usados por {cliente.nome}!','verde')
        else:
            textoColorido(f'Saldo insuficiente de pontos','vermelho')

