from textoColorido import textoColorido
id=1
class Produto:
    produtos=[]

    def __init__(self,nome,ingredientes,preco): # Método de criação de um objeto da classe Produto
        global id
        self.id=id
        id=id+1
        self.nome=nome
        self.ingredientes=ingredientes
        self.preco=preco
        self.precoSemPromocao=preco # Relembra o preço inicial, para quando a promoção for encerrar
        Produto.produtos.append(self) # Adiciona o novo Produto à lista
        textoColorido(f'Produto criado com sucesso!','verde')
    def alterarPreco(self,novoPreco):
        self.preco=novoPreco
    def listar():
        # Checagem de Produtos com suas descrições e preços atuais
        textoColorido('Produtos:','azul')
        for p in Produto.produtos:
            if(p.preco!=p.precoSemPromocao):
                textoColorido(f'ID:{p.id} - {p.nome} - R$ {p.preco:.2f} (Promoção)','amarelo')
            else:
                textoColorido(f'ID:{p.id} - {p.nome} - R$ {p.preco:.2f}','amarelo')
            print(f'Ingredientes: {p.ingredientes}')
    def criarPromocao(produto,novoPreco):
        produto.alterarPreco(novoPreco) # Define o novo preço da promoção
        textoColorido(f'Promoção feita com sucesso!','verde')
    def encerrarPromocao(produto):
        if(produto.preco==produto.precoSemPromocao): # Checa se o preço atual é o mesmo do original
            textoColorido(f'Este Produto não está na promoção','vermelho')
        else:
            produto.alterarPreco(produto.precoSemPromocao) # Volta o preço original do Produto
            textoColorido(f'Promoção encerrada com sucesso!','verde')
    def encontrarProdutoPorId(idProduto):
        for p in Produto.produtos:
            if(p.id==idProduto):
                return p