from ClasseProduto import Produto
from textoColorido import textoColorido
def escolhaProduto():
    textoColorido('Criar ou listar?','azul')
    textoColorido('1-Criar | 2-Listar | 3-Criar Promoção | 4-Encerrar Promoção','azul')
    texto=input('')
    if(not texto.isdigit()):
        textoColorido('Número inválido','vermelho')
        return
    decisao=int(texto)
    if(decisao==1): # Criação de Produto
        textoColorido('Digite o nome:','azul')
        nome=input('')
        textoColorido('Digite os ingredientes:','azul')
        ingredientes=input('')
        textoColorido('Digite o preço no formato 0:00:','azul')
        texto=input('')
        if(not texto.replace('.','').isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        preco=float(texto)
        Produto(nome,ingredientes,preco)
    elif(decisao==2): # Checagem de Produtos
        Produto.listar()
    elif(decisao==3): # Fazer promoção de um produto
        textoColorido('Digite o id do Produto:','azul')
        texto=input('')
        if (not texto.isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        idProduto=int(texto)
        produto=Produto.encontrarProdutoPorId(idProduto)
        if(not produto):
            textoColorido('Não existe Produto com este id','vermelho')
            return
        textoColorido('Digite o preço da promoção no formato 0:00:','azul')
        texto=input('')
        if (not texto.replace('.','').isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        preco=float(texto)
        Produto.criarPromocao(produto,preco)
    elif(decisao==4): # Encerrar uma promoção já criada
        textoColorido('Digite o id do Produto:','azul')
        texto=input('')
        if (not texto.isdigit()):
            textoColorido('Número inválido','vermelho')
            return
        idProduto=int(texto)
        produto=Produto.encontrarProdutoPorId(idProduto)
        if(not produto):
            textoColorido('Não existe Produto com este id','vermelho')
            return
        Produto.encerrarPromocao(produto)
    else:
        textoColorido('Número inválido','vermelho')