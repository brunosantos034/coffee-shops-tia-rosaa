from ClasseProduto import Produto
from ClasseCliente import Cliente
from textoColorido import textoColorido
id=1
class Pedido:
    pedidos=[]

    def __init__(self,cliente): # Método de criação de um objeto da classe Pedido
        global id
        self.id=id
        id=id+1
        self.cliente=cliente
        self.listaProdutos=[] # Cria a lista onde serão adicionados os itens do Pedido
        self.total=0
        Pedido.pedidos.append(self) # Adiciona o novo Pedido à lista
        
    def adicionarProduto(self,produto):
        # Adiciona um dicionário com o Produto e o Preço pago (já que ele pode ser feito em quanto tinha desconto)
        self.listaProdutos.append({'infos':produto,'precoComprado':produto.preco})
    def finalizarPedido(self):
        t=0
        for dicionarioProduto in self.listaProdutos:
            # Passa por cada Produto e adiciona o preço atual ao total
            t=t+dicionarioProduto['precoComprado']
        self.total=t
        cliente=self.cliente
        textoColorido(f'Pedido criado com sucesso!','verde')
        Cliente.aumentarPontos(cliente,t) # Adiciona pontos ao Cliente, baseado no preço (a relação pontos/valor é feita na classe Cliente)
        Pedido.imprimirPedido(self)
    def listar():
        # Checagem de Pedidos
        textoColorido('Pedidos:','azul')
        for p in Pedido.pedidos:
            Pedido.imprimirPedido(p)
            
    def imprimirPedido(p):
        # Método que imprime as informações do Pedido como os itens e o total a pagar
        textoColorido(f'ID:{p.id} - Cliente: {p.cliente.nome} (id Cliente:{p.cliente.id})','amarelo')
        for dicionarioProduto in p.listaProdutos:
            produto=dicionarioProduto['infos']
            precoComprado=dicionarioProduto['precoComprado']
            if(precoComprado!=produto.precoSemPromocao):
                print(f'R$ {precoComprado:.2f} - {produto.nome} (Promoção)')
            else:
                print(f'R$ {precoComprado:.2f} - {produto.nome}')
        textoColorido(f'Total: R$ {p.total:.2f}','verde')
        print('====================')